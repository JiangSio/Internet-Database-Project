// ==UserScript==
// @name         禁止投币
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  禁止给视频投币
// @author       You
// @match        https://www.bilibili.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=bilibili.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    document.querySelector(".coin").onmousedown=function(){document.querySelector(".coin").hidden = true;}
    document.onmouseup=function(){document.querySelector(".coin").hidden = false;}
})();